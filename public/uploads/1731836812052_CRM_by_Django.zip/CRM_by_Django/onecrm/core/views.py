from django.shortcuts import render

# Create your views here.
def request():
    return render(request, 'core/index.html')