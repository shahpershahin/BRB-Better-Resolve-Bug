## This ONECRM is created by using DJANGO framework
